  //JSON data   
  const cardData = [{
    "albumId": 11,
    "id": 501,
    "title": "asperiores exercitationem voluptates qui amet quae necessitatibus facere",
    "url": "https://via.placeholder.com/600/cda4c0",
    "thumbnailUrl": "https://via.placeholder.com/150/cda4c0"
  },
  {
    "albumId": 11,
    "id": 502,
    "title": "omnis qui sit et",
    "url": "https://via.placeholder.com/600/74e371",
    "thumbnailUrl": "https://via.placeholder.com/150/74e371"
  },
  {
    "albumId": 11,
    "id": 503,
    "title": "modi voluptas fugiat eos",
    "url": "https://via.placeholder.com/600/9022fb",
    "thumbnailUrl": "https://via.placeholder.com/150/9022fb"
  },
  {
    "albumId": 11,
    "id": 504,
    "title": "sapiente id vel dignissimos",
    "url": "https://via.placeholder.com/600/99dd3f",
    "thumbnailUrl": "https://via.placeholder.com/150/99dd3f"
  },
  {
    "albumId": 11,
    "id": 505,
    "title": "quam voluptatibus ea saepe",
    "url": "https://via.placeholder.com/600/1cb49b",
    "thumbnailUrl": "https://via.placeholder.com/150/1cb49b"
  },
  {
    "albumId": 11,
    "id": 506,
    "title": "maxime unde repudiandae similique reiciendis harum",
    "url": "https://via.placeholder.com/600/91f992",
    "thumbnailUrl": "https://via.placeholder.com/150/91f992"
  },
  {
    "albumId": 11,
    "id": 507,
    "title": "doloremque nulla ab in sed possimus",
    "url": "https://via.placeholder.com/600/dfe687",
    "thumbnailUrl": "https://via.placeholder.com/150/dfe687"
  },
  {
    "albumId": 11,
    "id": 508,
    "title": "et officiis maxime consequatur magnam",
    "url": "https://via.placeholder.com/600/c4e0b1",
    "thumbnailUrl": "https://via.placeholder.com/150/c4e0b1"
  },
  {
    "albumId": 11,
    "id": 509,
    "title": "eligendi cum voluptate ipsum alias laudantium in",
    "url": "https://via.placeholder.com/600/963d65",
    "thumbnailUrl": "https://via.placeholder.com/150/963d65"
  },
  {
    "albumId": 11,
    "id": 510,
    "title": "commodi labore impedit ipsam quasi dignissimos culpa ut",
    "url": "https://via.placeholder.com/600/4e59cd",
    "thumbnailUrl": "https://via.placeholder.com/150/4e59cd"
  },
  {
    "albumId": 11,
    "id": 511,
    "title": "officia tenetur sed",
    "url": "https://via.placeholder.com/600/4016ae",
    "thumbnailUrl": "https://via.placeholder.com/150/4016ae"
  },
  {
    "albumId": 11,
    "id": 512,
    "title": "tenetur delectus et ea ut quae quisquam necessitatibus",
    "url": "https://via.placeholder.com/600/a45dfe",
    "thumbnailUrl": "https://via.placeholder.com/150/a45dfe"
  },
  {
    "albumId": 11,
    "id": 513,
    "title": "et aut quas earum placeat eligendi sequi dolor ratione",
    "url": "https://via.placeholder.com/600/893903",
    "thumbnailUrl": "https://via.placeholder.com/150/893903"
  },
  {
    "albumId": 11,
    "id": 514,
    "title": "eveniet repellat sint molestiae enim non qui",
    "url": "https://via.placeholder.com/600/664a83",
    "thumbnailUrl": "https://via.placeholder.com/150/664a83"
  },
  {
    "albumId": 11,
    "id": 515,
    "title": "reprehenderit blanditiis voluptatum quae magni",
    "url": "https://via.placeholder.com/600/61c959",
    "thumbnailUrl": "https://via.placeholder.com/150/61c959"
  },
  {
    "albumId": 11,
    "id": 516,
    "title": "placeat quia voluptas quos aut nobis ut officia adipisci",
    "url": "https://via.placeholder.com/600/452ba6",
    "thumbnailUrl": "https://via.placeholder.com/150/452ba6"
  },
  {
    "albumId": 11,
    "id": 517,
    "title": "et omnis in rerum",
    "url": "https://via.placeholder.com/600/9c4d5d",
    "thumbnailUrl": "https://via.placeholder.com/150/9c4d5d"
  },
  {
    "albumId": 11,
    "id": 518,
    "title": "qui quia aspernatur officia quo est alias cupiditate",
    "url": "https://via.placeholder.com/600/a4b943",
    "thumbnailUrl": "https://via.placeholder.com/150/a4b943"
  },
  {
    "albumId": 11,
    "id": 519,
    "title": "ut minima nemo",
    "url": "https://via.placeholder.com/600/c44dff",
    "thumbnailUrl": "https://via.placeholder.com/150/c44dff"
  },
  {
    "albumId": 11,
    "id": 520,
    "title": "id quo et dicta et sed id omnis",
    "url": "https://via.placeholder.com/600/143863",
    "thumbnailUrl": "https://via.placeholder.com/150/143863"
  },
  {
    "albumId": 11,
    "id": 521,
    "title": "nesciunt molestiae et est laudantium nisi qui perspiciatis quibusdam",
    "url": "https://via.placeholder.com/600/7cc030",
    "thumbnailUrl": "https://via.placeholder.com/150/7cc030"
  },
  {
    "albumId": 11,
    "id": 522,
    "title": "ipsam assumenda dolores nulla id consequatur",
    "url": "https://via.placeholder.com/600/34f26b",
    "thumbnailUrl": "https://via.placeholder.com/150/34f26b"
  },
  {
    "albumId": 11,
    "id": 523,
    "title": "similique qui voluptatibus molestiae sed dicta sit",
    "url": "https://via.placeholder.com/600/59fd84",
    "thumbnailUrl": "https://via.placeholder.com/150/59fd84"
  },
  {
    "albumId": 11,
    "id": 524,
    "title": "nisi est dignissimos doloribus quisquam",
    "url": "https://via.placeholder.com/600/bd8435",
    "thumbnailUrl": "https://via.placeholder.com/150/bd8435"
  },
  {
    "albumId": 11,
    "id": 525,
    "title": "maiores nostrum nam consequatur illo ipsam",
    "url": "https://via.placeholder.com/600/7bccd9",
    "thumbnailUrl": "https://via.placeholder.com/150/7bccd9"
  },
  {
    "albumId": 11,
    "id": 526,
    "title": "ullam eum molestias facere",
    "url": "https://via.placeholder.com/600/e2374f",
    "thumbnailUrl": "https://via.placeholder.com/150/e2374f"
  },
  {
    "albumId": 11,
    "id": 527,
    "title": "laborum non occaecati tenetur ut repellendus",
    "url": "https://via.placeholder.com/600/ef43fa",
    "thumbnailUrl": "https://via.placeholder.com/150/ef43fa"
  },
  {
    "albumId": 11,
    "id": 528,
    "title": "accusamus dignissimos ad quo sint asperiores voluptas repellendus",
    "url": "https://via.placeholder.com/600/37efd",
    "thumbnailUrl": "https://via.placeholder.com/150/37efd"
  },
  {
    "albumId": 11,
    "id": 529,
    "title": "ipsa sint consequatur sint",
    "url": "https://via.placeholder.com/600/812555",
    "thumbnailUrl": "https://via.placeholder.com/150/812555"
  },
  {
    "albumId": 11,
    "id": 530,
    "title": "labore impedit cum distinctio sapiente eveniet praesentium et",
    "url": "https://via.placeholder.com/600/a08784",
    "thumbnailUrl": "https://via.placeholder.com/150/a08784"
  },
  {
    "albumId": 11,
    "id": 531,
    "title": "ut corrupti minima ut",
    "url": "https://via.placeholder.com/600/c55662",
    "thumbnailUrl": "https://via.placeholder.com/150/c55662"
  },
  {
    "albumId": 11,
    "id": 532,
    "title": "harum qui ducimus commodi repellat iusto",
    "url": "https://via.placeholder.com/600/eb4341",
    "thumbnailUrl": "https://via.placeholder.com/150/eb4341"
  },
  {
    "albumId": 11,
    "id": 533,
    "title": "earum quia qui inventore enim",
    "url": "https://via.placeholder.com/600/89ef74",
    "thumbnailUrl": "https://via.placeholder.com/150/89ef74"
  },
  {
    "albumId": 11,
    "id": 534,
    "title": "non voluptas quasi quia quo quam",
    "url": "https://via.placeholder.com/600/12f36e",
    "thumbnailUrl": "https://via.placeholder.com/150/12f36e"
  },
  {
    "albumId": 11,
    "id": 535,
    "title": "illum est fuga",
    "url": "https://via.placeholder.com/600/124f3a",
    "thumbnailUrl": "https://via.placeholder.com/150/124f3a"
  },
  {
    "albumId": 11,
    "id": 536,
    "title": "non sequi est delectus ullam impedit voluptatum sunt",
    "url": "https://via.placeholder.com/600/e309a5",
    "thumbnailUrl": "https://via.placeholder.com/150/e309a5"
  },
  {
    "albumId": 11,
    "id": 537,
    "title": "ea libero et consectetur enim fugiat et tempore",
    "url": "https://via.placeholder.com/600/bcb3cc",
    "thumbnailUrl": "https://via.placeholder.com/150/bcb3cc"
  },
  {
    "albumId": 11,
    "id": 538,
    "title": "animi vero et",
    "url": "https://via.placeholder.com/600/1a2898",
    "thumbnailUrl": "https://via.placeholder.com/150/1a2898"
  },
  {
    "albumId": 11,
    "id": 539,
    "title": "repudiandae aliquam beatae eveniet voluptas illum",
    "url": "https://via.placeholder.com/600/d7cf9b",
    "thumbnailUrl": "https://via.placeholder.com/150/d7cf9b"
  },
  {
    "albumId": 11,
    "id": 540,
    "title": "eum et quia voluptatem unde",
    "url": "https://via.placeholder.com/600/d9acde",
    "thumbnailUrl": "https://via.placeholder.com/150/d9acde"
  },
  {
    "albumId": 11,
    "id": 541,
    "title": "quia molestiae repellendus expedita quis consequatur enim",
    "url": "https://via.placeholder.com/600/343aa4",
    "thumbnailUrl": "https://via.placeholder.com/150/343aa4"
  },
  {
    "albumId": 11,
    "id": 542,
    "title": "perferendis aliquid et nulla occaecati voluptas tempore",
    "url": "https://via.placeholder.com/600/187191",
    "thumbnailUrl": "https://via.placeholder.com/150/187191"
  },
  {
    "albumId": 11,
    "id": 543,
    "title": "ratione culpa unde et et voluptas",
    "url": "https://via.placeholder.com/600/5f8db6",
    "thumbnailUrl": "https://via.placeholder.com/150/5f8db6"
  },
  {
    "albumId": 11,
    "id": 544,
    "title": "ex totam aliquam consequatur voluptas est",
    "url": "https://via.placeholder.com/600/2dfa38",
    "thumbnailUrl": "https://via.placeholder.com/150/2dfa38"
  },
  {
    "albumId": 11,
    "id": 545,
    "title": "id explicabo qui cumque ut et repellendus aut",
    "url": "https://via.placeholder.com/600/69125",
    "thumbnailUrl": "https://via.placeholder.com/150/69125"
  },
  {
    "albumId": 11,
    "id": 546,
    "title": "et ullam libero in aliquid",
    "url": "https://via.placeholder.com/600/8b5af6",
    "thumbnailUrl": "https://via.placeholder.com/150/8b5af6"
  },
  {
    "albumId": 11,
    "id": 547,
    "title": "libero ut vero et et voluptatem",
    "url": "https://via.placeholder.com/600/e94d9b",
    "thumbnailUrl": "https://via.placeholder.com/150/e94d9b"
  },
  {
    "albumId": 11,
    "id": 548,
    "title": "culpa ea consequuntur tempora et voluptas ipsum voluptatem",
    "url": "https://via.placeholder.com/600/9cc2e7",
    "thumbnailUrl": "https://via.placeholder.com/150/9cc2e7"
  },
  {
    "albumId": 11,
    "id": 549,
    "title": "repudiandae dolorum corporis unde",
    "url": "https://via.placeholder.com/600/f75bc8",
    "thumbnailUrl": "https://via.placeholder.com/150/f75bc8"
  },
  {
    "albumId": 11,
    "id": 550,
    "title": "eaque ut incidunt quae aut quo quis praesentium",
    "url": "https://via.placeholder.com/600/ff382e",
    "thumbnailUrl": "https://via.placeholder.com/150/ff382e"
  },
  {
    "albumId": 12,
    "id": 551,
    "title": "eveniet debitis nihil",
    "url": "https://via.placeholder.com/600/21e334",
    "thumbnailUrl": "https://via.placeholder.com/150/21e334"
  },
  {
    "albumId": 12,
    "id": 552,
    "title": "odit culpa optio nesciunt",
    "url": "https://via.placeholder.com/600/b56655",
    "thumbnailUrl": "https://via.placeholder.com/150/b56655"
  },
  {
    "albumId": 12,
    "id": 553,
    "title": "doloribus illo aperiam ut ducimus",
    "url": "https://via.placeholder.com/600/6f666f",
    "thumbnailUrl": "https://via.placeholder.com/150/6f666f"
  },
  {
    "albumId": 12,
    "id": 554,
    "title": "dolorem cupiditate culpa et voluptas neque nemo architecto facere",
    "url": "https://via.placeholder.com/600/e719ba",
    "thumbnailUrl": "https://via.placeholder.com/150/e719ba"
  },
  {
    "albumId": 12,
    "id": 555,
    "title": "dicta ullam laboriosam enim laudantium quos voluptatibus tempora",
    "url": "https://via.placeholder.com/600/9231f2",
    "thumbnailUrl": "https://via.placeholder.com/150/9231f2"
  },
  {
    "albumId": 12,
    "id": 556,
    "title": "est esse est non quo",
    "url": "https://via.placeholder.com/600/962310",
    "thumbnailUrl": "https://via.placeholder.com/150/962310"
  },
  {
    "albumId": 12,
    "id": 557,
    "title": "voluptatem in quia temporibus",
    "url": "https://via.placeholder.com/600/a4885b",
    "thumbnailUrl": "https://via.placeholder.com/150/a4885b"
  },
  {
    "albumId": 12,
    "id": 558,
    "title": "omnis occaecati dolorem placeat voluptates officia perspiciatis",
    "url": "https://via.placeholder.com/600/170e98",
    "thumbnailUrl": "https://via.placeholder.com/150/170e98"
  },
  {
    "albumId": 12,
    "id": 559,
    "title": "dolor odio unde quaerat",
    "url": "https://via.placeholder.com/600/e82066",
    "thumbnailUrl": "https://via.placeholder.com/150/e82066"
  },
  {
    "albumId": 12,
    "id": 560,
    "title": "nostrum et explicabo qui distinctio",
    "url": "https://via.placeholder.com/600/91ff13",
    "thumbnailUrl": "https://via.placeholder.com/150/91ff13"
  },
  {
    "albumId": 12,
    "id": 561,
    "title": "nostrum eum autem",
    "url": "https://via.placeholder.com/600/79c855",
    "thumbnailUrl": "https://via.placeholder.com/150/79c855"
  },
  {
    "albumId": 12,
    "id": 562,
    "title": "facere veritatis temporibus autem impedit",
    "url": "https://via.placeholder.com/600/3e4a11",
    "thumbnailUrl": "https://via.placeholder.com/150/3e4a11"
  },
  {
    "albumId": 12,
    "id": 563,
    "title": "quis eveniet corporis consectetur numquam",
    "url": "https://via.placeholder.com/600/fd60dc",
    "thumbnailUrl": "https://via.placeholder.com/150/fd60dc"
  },
  {
    "albumId": 12,
    "id": 564,
    "title": "eum est facilis voluptatem similique",
    "url": "https://via.placeholder.com/600/7dfc32",
    "thumbnailUrl": "https://via.placeholder.com/150/7dfc32"
  },
  {
    "albumId": 12,
    "id": 565,
    "title": "animi quo deleniti perspiciatis aut dolorum laudantium",
    "url": "https://via.placeholder.com/600/ac5e1f",
    "thumbnailUrl": "https://via.placeholder.com/150/ac5e1f"
  },
  {
    "albumId": 12,
    "id": 566,
    "title": "in dolorem doloremque qui",
    "url": "https://via.placeholder.com/600/8d7f0a",
    "thumbnailUrl": "https://via.placeholder.com/150/8d7f0a"
  },
  {
    "albumId": 12,
    "id": 567,
    "title": "non accusantium maiores",
    "url": "https://via.placeholder.com/600/6c26b3",
    "thumbnailUrl": "https://via.placeholder.com/150/6c26b3"
  },
  {
    "albumId": 12,
    "id": 568,
    "title": "eveniet dolores et aspernatur voluptatem",
    "url": "https://via.placeholder.com/600/4fd3a8",
    "thumbnailUrl": "https://via.placeholder.com/150/4fd3a8"
  },
  {
    "albumId": 12,
    "id": 569,
    "title": "quia debitis vitae repudiandae expedita aliquid",
    "url": "https://via.placeholder.com/600/53e006",
    "thumbnailUrl": "https://via.placeholder.com/150/53e006"
  },
  {
    "albumId": 12,
    "id": 570,
    "title": "rem molestiae error qui qui corrupti excepturi",
    "url": "https://via.placeholder.com/600/3f3a07",
    "thumbnailUrl": "https://via.placeholder.com/150/3f3a07"
  },
  {
    "albumId": 12,
    "id": 571,
    "title": "voluptatem voluptas suscipit nesciunt maxime ad dolorum error",
    "url": "https://via.placeholder.com/600/dc8dc8",
    "thumbnailUrl": "https://via.placeholder.com/150/dc8dc8"
  },
  {
    "albumId": 12,
    "id": 572,
    "title": "ea sit error est",
    "url": "https://via.placeholder.com/600/38a038",
    "thumbnailUrl": "https://via.placeholder.com/150/38a038"
  },
  {
    "albumId": 12,
    "id": 573,
    "title": "consequuntur aut omnis quo autem",
    "url": "https://via.placeholder.com/600/eab30e",
    "thumbnailUrl": "https://via.placeholder.com/150/eab30e"
  },
  {
    "albumId": 12,
    "id": 574,
    "title": "omnis et earum saepe iure",
    "url": "https://via.placeholder.com/600/22bc26",
    "thumbnailUrl": "https://via.placeholder.com/150/22bc26"
  },
  {
    "albumId": 12,
    "id": 575,
    "title": "animi doloribus dolores deserunt",
    "url": "https://via.placeholder.com/600/cd4d19",
    "thumbnailUrl": "https://via.placeholder.com/150/cd4d19"
  },
  {
    "albumId": 12,
    "id": 576,
    "title": "aliquam explicabo iusto quisquam fugit ipsam voluptatem recusandae sed",
    "url": "https://via.placeholder.com/600/26194f",
    "thumbnailUrl": "https://via.placeholder.com/150/26194f"
  },
  {
    "albumId": 12,
    "id": 577,
    "title": "unde ex repudiandae iusto laudantium deserunt voluptas",
    "url": "https://via.placeholder.com/600/16ce34",
    "thumbnailUrl": "https://via.placeholder.com/150/16ce34"
  },
  {
    "albumId": 12,
    "id": 578,
    "title": "perferendis eum et similique expedita enim dolor sequi sit",
    "url": "https://via.placeholder.com/600/c9a6f9",
    "thumbnailUrl": "https://via.placeholder.com/150/c9a6f9"
  },
  {
    "albumId": 12,
    "id": 579,
    "title": "nihil optio et aut enim provident fugit repudiandae est",
    "url": "https://via.placeholder.com/600/70e96e",
    "thumbnailUrl": "https://via.placeholder.com/150/70e96e"
  },
  {
    "albumId": 12,
    "id": 580,
    "title": "molestiae odit inventore",
    "url": "https://via.placeholder.com/600/a77cdc",
    "thumbnailUrl": "https://via.placeholder.com/150/a77cdc"
  },
  {
    "albumId": 12,
    "id": 581,
    "title": "consequatur atque saepe qui ea",
    "url": "https://via.placeholder.com/600/e6db39",
    "thumbnailUrl": "https://via.placeholder.com/150/e6db39"
  },
  {
    "albumId": 12,
    "id": 582,
    "title": "aspernatur iure aliquam voluptas minus omnis",
    "url": "https://via.placeholder.com/600/f68708",
    "thumbnailUrl": "https://via.placeholder.com/150/f68708"
  },
  {
    "albumId": 12,
    "id": 583,
    "title": "aut maiores explicabo unde sit molestiae inventore qui earum",
    "url": "https://via.placeholder.com/600/4962a8",
    "thumbnailUrl": "https://via.placeholder.com/150/4962a8"
  },
  {
    "albumId": 12,
    "id": 584,
    "title": "atque qui voluptatem",
    "url": "https://via.placeholder.com/600/1fc692",
    "thumbnailUrl": "https://via.placeholder.com/150/1fc692"
  },
  {
    "albumId": 12,
    "id": 585,
    "title": "dolore voluptatem est itaque voluptatem expedita nostrum",
    "url": "https://via.placeholder.com/600/b668c4",
    "thumbnailUrl": "https://via.placeholder.com/150/b668c4"
  },
  {
    "albumId": 12,
    "id": 586,
    "title": "nihil et voluptatem cumque qui",
    "url": "https://via.placeholder.com/600/5fb3e2",
    "thumbnailUrl": "https://via.placeholder.com/150/5fb3e2"
  },
  {
    "albumId": 12,
    "id": 587,
    "title": "exercitationem eos possimus provident",
    "url": "https://via.placeholder.com/600/9bdef5",
    "thumbnailUrl": "https://via.placeholder.com/150/9bdef5"
  },
  {
    "albumId": 12,
    "id": 588,
    "title": "eveniet rem possimus amet praesentium quia dolorem doloribus sit",
    "url": "https://via.placeholder.com/600/76b24e",
    "thumbnailUrl": "https://via.placeholder.com/150/76b24e"
  },
  {
    "albumId": 12,
    "id": 589,
    "title": "eum velit quo voluptate explicabo culpa est quidem",
    "url": "https://via.placeholder.com/600/26c0e2",
    "thumbnailUrl": "https://via.placeholder.com/150/26c0e2"
  },
  {
    "albumId": 12,
    "id": 590,
    "title": "debitis qui et recusandae dicta qui voluptate deleniti",
    "url": "https://via.placeholder.com/600/b279d1",
    "thumbnailUrl": "https://via.placeholder.com/150/b279d1"
  },
  {
    "albumId": 12,
    "id": 591,
    "title": "id porro voluptas dolores excepturi nesciunt quis inventore aut",
    "url": "https://via.placeholder.com/600/9367c3",
    "thumbnailUrl": "https://via.placeholder.com/150/9367c3"
  },
  {
    "albumId": 12,
    "id": 592,
    "title": "eveniet assumenda exercitationem iure alias enim",
    "url": "https://via.placeholder.com/600/c8f64b",
    "thumbnailUrl": "https://via.placeholder.com/150/c8f64b"
  },
  {
    "albumId": 12,
    "id": 593,
    "title": "culpa autem officiis",
    "url": "https://via.placeholder.com/600/ac824f",
    "thumbnailUrl": "https://via.placeholder.com/150/ac824f"
  },
  {
    "albumId": 12,
    "id": 594,
    "title": "at repudiandae earum vel qui doloremque itaque sed",
    "url": "https://via.placeholder.com/600/184c5",
    "thumbnailUrl": "https://via.placeholder.com/150/184c5"
  },
  {
    "albumId": 12,
    "id": 595,
    "title": "ullam nihil quis",
    "url": "https://via.placeholder.com/600/59c24",
    "thumbnailUrl": "https://via.placeholder.com/150/59c24"
  },
  {
    "albumId": 12,
    "id": 596,
    "title": "natus corporis suscipit nihil nesciunt aliquam",
    "url": "https://via.placeholder.com/600/165672",
    "thumbnailUrl": "https://via.placeholder.com/150/165672"
  },
  {
    "albumId": 12,
    "id": 597,
    "title": "in deleniti voluptas ea facere",
    "url": "https://via.placeholder.com/600/da527d",
    "thumbnailUrl": "https://via.placeholder.com/150/da527d"
  },
  {
    "albumId": 12,
    "id": 598,
    "title": "ut id id est",
    "url": "https://via.placeholder.com/600/1b07a7",
    "thumbnailUrl": "https://via.placeholder.com/150/1b07a7"
  },
  {
    "albumId": 12,
    "id": 599,
    "title": "aperiam ut possimus",
    "url": "https://via.placeholder.com/600/433cca",
    "thumbnailUrl": "https://via.placeholder.com/150/433cca"
  },
  {
    "albumId": 12,
    "id": 600,
    "title": "quidem id aut ut praesentium minima eos autem quia",
    "url": "https://via.placeholder.com/600/8d7f5a",
    "thumbnailUrl": "https://via.placeholder.com/150/8d7f5a"
  }
];

const postContainer = document.querySelector('.card-container');


//dynamic cards
const postMethod = () =>{
    cardData.map((postData)=>{
        const postElement = document.createElement('div');
        postElement.classList.add('card');
        postElement.innerHTML=`
        <img src="${postData.thumbnailUrl}"/>
        <h3 class="card-heading">${postData.title}</h3>
        <a href="${postData.url}"><button>Display image in new tab</button></a>`
        postContainer.appendChild(postElement)
    })
}
postMethod()


let thisPage = 1;
let limit = 10;
let list = document.querySelectorAll('.card-container .card');


//load cards for current page
function loadItem(){
    let beginGet = limit * (thisPage - 1);
    let endGet = limit * thisPage - 1;
    list.forEach((item,key)=>{
        if(key>=beginGet && key<=endGet){
            item.style.display='block';
        }
        else{
            item.style.display='none';
        }
    })
    listPage();
}
loadItem();


//update pagination list
function listPage(){
    let count=Math.ceil(list.length/limit);
    document.querySelector('.listPage').innerHTML = '';
    for(i=1; i<=count; i++){
        let newPage = document.createElement('li');
        newPage.innerText=i;
        if(i==thisPage){
            newPage.classList.add('active');
        }
        newPage.setAttribute('onclick', "changePage("+i+")");
        document.querySelector('.listPage').appendChild(newPage);
    }
}


function backtoTop() {
    const element = document.getElementById("demo");
    element.scrollLeft = 50;
    element.scrollTop = 10;
  }


//change current page
function changePage(i){
    thisPage=i;
    loadItem();
    backtoTop();
}

